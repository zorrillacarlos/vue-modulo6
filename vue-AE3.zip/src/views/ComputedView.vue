<template>
  <Computed />
</template>

<script>
import Computed from '@/components/Computed.vue'
export default {
    name:'ComputedView',
    components:{
        Computed,
    }

}
</script>

<style>

</style>
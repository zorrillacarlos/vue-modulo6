<template>
  <Formulario />
</template>

<script>
import Formulario from '@/components/Formulario.vue'

export default {
    name: 'FormsView',

    components:{
        Formulario,
    }
    }
</script>

<style>

</style>
<template>
  <h2 class="bg-primary text-center p-5 text-light">Rick And Morty API</h2>
</template>

<script>

export default {

}
</script>

<style>

</style>
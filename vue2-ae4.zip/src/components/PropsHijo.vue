<template>
  <div class="container">
    <h1>{{ mensajeProps }}</h1>
    <br><br>
    <button class="btn btn-danger" @click="funcionProps()">Ejecutar funcion</button>
  </div>
</template>

<script>
export default {
  name:'PropsHijo',
  props: {
    mensajeProps: String,
    funcionProps: Function,
  },
};
</script>

<style></style>

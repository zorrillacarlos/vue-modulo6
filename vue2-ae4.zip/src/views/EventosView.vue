<template>
    <Eventos />
</template>

<script>
import Eventos from "@/components/Eventos.vue";
export default {
  name: "EventosView",
  components: {
    Eventos,
  },
};
</script>

<style></style>

<template>
  <div class="container">
    <PropsPadre />
  </div>
</template>

<script>
import PropsPadre from "@/components/PropsPadre.vue";

export default {
  name: "PropsVue",
  components: {
    PropsPadre,
  },
};
</script>

<style></style>

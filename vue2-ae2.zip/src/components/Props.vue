<template>
  <div>
    <h2>Props</h2>
    <p>
      En los props podemos mandar variables simples, listas de array, funciones
      que se declaren en el componente padre y luego se ejecuten en el
      componente hijo y objetos con mucha informacion para que el componente
      hijo lo renderice
    </p>
    <h3>{{ msgProps }}</h3>
    <br />
    <button @click="hacerClickProps()" class="btn btn-danger">
      Hago click en este boton en el componente hijo
    </button>
    <hr />
    <h2>Computed (Propiedades computadas)</h2>
    <p>
    Básicamente computed es una variable, la diferencia con las Variables de Vue es que las computadas normalmente transforman la variable o hacen algún tipo de cálculo antes de devolverla.
    </p>
    <p>Además resuelve el problema que vimos de que no puedes crear una variable que tenga el valor de otra variable del data.</p>

    <h2>Ejemplo 1</h2>
    <h4>El nivel de experiencia es {{ role }} en {{ exp }} años y esos años multiplicados por 2 son {{ calExp }}</h4>


    <input type="text" v-model="name" />
    <button class="btn btn-warning" @click="agregarProgramador()">
      Agregar Programador a la Lista</button>
      <br /><br />

    <h3>El nombre ingresado es: {{ name }}</h3>
    <h3 class="mb-5">El nombre invertido es: {{ nombreInvertido }}</h3>

    <h2>LISTA DE PROGRAMADORES</h2>
    <ul v-for="(programador, index) in nombreProgramador" :key="index">
      <li>{{ programador }}</li>
    </ul>
    <br /><br /><br /><br />
  </div>
</template>

<script>
export default {
  name: "Props",

    props:{
      msgProps: {
      type: String,
      //default: "Mensaje Default",
      required: true,
      //validator: Comprueba si el valor de la prop es válida o no.
    },
      hacerClickProps: Function,
    },

/*   props: {
    msgProps: {
      type: String,
      default: "Mensaje Default",
      required: true,
      //validator: Comprueba si el valor de la prop es válida o no.
    },
    hacerClickProps: Function,
  }, */








  data() {
    return {
      exp: 5,
      name: "Juan",
      nombreProgramador: [],
    };
  },


  // https://codingpotions.com/vue-computadas
  computed: {
    role() {
      return this.exp > 12 ? "Expert"
        : this.exp > 8 ? "Senior"
        : this.exp > 4 ? "Middle"
        : "Junior";
        // https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Operators/Conditional_Operator
    },
    nombreInvertido() {
      return this.name.split("").reverse().join("");
      //split separa nuestro string en un arreglo
      //reverse invierte el orden de nuestro arreglo
      //join para juntar nuestro arreglo y pasamos un separador
    },
    calExp (){
      return this.exp * 2;
    }
  },



  methods: {
    agregarProgramador() {
      this.nombreProgramador.push(this.name);
    },

  },
};
</script>

<style></style>

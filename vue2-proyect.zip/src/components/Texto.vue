<template>
<div>
 <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae adipisci aspernatur veniam, rem ad magni fugiat quod harum placeat provident minima culpa qui! Culpa laudantium id, minima quae labore ullam? Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam ab voluptatibus dolore! Obcaecati sit inventore, id quasi corporis amet in ratione ipsa, enim rerum, eligendi ducimus non saepe cum magnam!</p>
</div>
 
</template>

<script>
export default {

}
</script>

<style>

</style>